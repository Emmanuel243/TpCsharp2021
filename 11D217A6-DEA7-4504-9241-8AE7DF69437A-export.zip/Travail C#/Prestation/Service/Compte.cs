using static System.Console;
namespace Prestation.Service
{
    public class Compte
    {
        public string Login{set; get;}
        public string MotDePass{set; get;}
    }
}