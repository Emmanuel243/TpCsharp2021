using static System.Console;
namespace Prestation.Service
{
    public class Prestation
    {
        public string Notice{set; get;}
    }
}