using static System.Console;
namespace Prestation.Service
{
    public class Service
    {
        public string NomService{set; get;}
        public string Description{set; get;}
        public double PrixService{set; get;}
        public string DureeService{set; get;}
    }
}