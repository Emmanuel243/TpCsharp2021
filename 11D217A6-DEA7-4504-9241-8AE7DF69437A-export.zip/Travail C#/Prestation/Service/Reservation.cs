using static System.Console;
namespace Prestation.Service
{
    public class Reservation
    {
        public string Numero{set; get;}
        public bool Etat{set; get;}
    }
}