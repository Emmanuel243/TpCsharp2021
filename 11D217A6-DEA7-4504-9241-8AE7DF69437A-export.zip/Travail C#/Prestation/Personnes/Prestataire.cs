using static System.Console;
namespace Prestation.Personnes
{
    public class prestataire{
        public string Telephone{set; get;}
        public string Email{set; get;}
        public bool Disponibilite{set; get;}
        public List<Service> Prestations { get; private set;}

        public void PosterPrestation(Service service)
        {
            Prestations.Add(Service);
        }

        public void ModifierPrestation(Service modifService)
        {
            service=modifService;
        }

        public void CreerCompte()
        {
            
        }

        public void SupprimerPrestation()
        {
            
        }
    }
}