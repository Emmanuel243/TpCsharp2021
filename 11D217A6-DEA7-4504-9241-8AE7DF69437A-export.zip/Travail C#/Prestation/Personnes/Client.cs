using static System.Console;
namespace Prestation.Personnes
{
    class Client : Personne
    {
        public string Telephone{get; set;}
        public string Email{get; set;}

        public void Consulter(){
            Console.WriteLine(NomService+" "+Description+" "+PrixService+" "+DureeService);
        }

        public void ReserverPrestation()
        {
            Reservation.Numero=null;
            Reservation.Etat=true;
        }

        public void CreerCompte(string login; string motDePass)
        {
            Compte.Login=login;
            Compte.MotDePasse=motDePass;
        }

        public void PayePrestation()
        {

        }
    }
}