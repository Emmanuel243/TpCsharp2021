using static System.Console;
namespace Prestation.Personne
{
    class Personne{
        public string Nom{get; set;}
        public string Postnom{get; set;}
        public string Prenom{get; set;}
        public int Age{get; set;}
        public string Genre{get; set;}
    }
}