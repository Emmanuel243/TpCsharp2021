﻿using System;
using Ecole.Models;
using System.Collections.Generic;
using static System.Console;
namespace Ecole
{
    class Program
    {
         public static List<Cours> cours=new List<Cours>();
         public static List<Etudiant> etudiants=new List<Etudiant>();
          public static List<Professeur> professeurs=new List<Professeur>();
          public static List<Enrollment> enrollments=new List<Enrollment>();
        static void Main(string[] args)
        {
            WriteLine("-------------------------------------\n\t\tGestion d'ecole\n-------------------------------------");
            var cours1=new Cours("009","Francais",45);
            var cours2=new Cours("008","Analyse math II",60);
            var cours3=new Cours("006","Reseaux",60);
            var cours4=new Cours("007","langage C",60);
            var cours5=new Cours("003","Comptabilite analytique",45);
            cours.Add(cours1);
            cours.Add(cours2);
            cours.Add(cours3);
            cours.Add(cours4);
            cours.Add(cours5);
            var et1=new Etudiant("KIPONA","MWEWA","Emmanuel",22,'M',"16KM179","16km179@esisalama.org",0.0);
            var et2=new Etudiant("KATETA","BYAYI","JOHNAS",24,'M',"17KB19","17kb19@esisalama.org",0.0);
            var et3=new Etudiant("BONDO","MBUYI","Jeremie",22,'M',"17BM79","17bm79@esisalama.org",0.0);
            var et4=new Etudiant("KALEND","A KABEY","Rosny",22,'M',"18KA89","18ka89@esisalama.org",0.0);
            var et5=new Etudiant("BINENE","SABWE","Gomer",23,'M',"18bs87","18bs89@esisalama.org",0.0);
            var et6=new Etudiant("KAKUDJI","MPUKA","Djo",23,'M',"18KM86","18km86@esisalama.org",0.0);
            etudiants.Add(et1);
            etudiants.Add(et2);
            etudiants.Add(et3);
            etudiants.Add(et4);
            etudiants.Add(et5);
            etudiants.Add(et6);
            var prof1 =new Professeur("KAKU","MENDE","Djo",35,'M',"10KM86","10km86@esisalama.org");
             var prof2 =new Professeur("KAKUDI","MOLA","Pierre",45,'M',"10KM88","10km88@esisalama.org");
             professeurs.Add(prof1);
             professeurs.Add(prof2);
             enrollments.Add(EnrollInEtudiant(et1,cours1));
            int choix;
             do{
                 choix=Menu();
                 switch(choix) {
                      case 1:Listercouse();break;
                      case 2:Enrollements();break;
                      case 3:ListerProfesseur();break;
                      case 4:ListerEtudiants(); break;
                      case 5: Quittez(); break;
                 } 
            }while(choix < 4);
        }
        static int Menu(){
            int choix=0;
            Console.WriteLine();
            Console.WriteLine("1 : Liste des cours");
            Console.WriteLine("2 : enrolements");
            Console.WriteLine("3 : Liste des professeurs");
            Console.WriteLine("4 : Liste des etudiants");
            Console.WriteLine("5 : Quittez");
            while ((choix != 1) && (choix != 2) && (choix != 3) && (choix != 4) && (choix != 5)){
                choix=Int16.Parse(Console.ReadLine());
            }
            return choix;
        }
        static void Quittez(){
            Console.WriteLine("Programme terminé !");
        }
        static void Listercouse(){
            WriteLine("--------------------------\n\tListe des Cours\n--------------------------\n"); 
            foreach (var Item in cours){
                WriteLine(Item);
            }
        }
          static void ListerEtudiants(){
            WriteLine("--------------------------\nListe des Etudiants\n--------------------------\n"); 
            foreach (var Item in etudiants){
                WriteLine(Item);
            }
        }
         static void ListerProfesseur(){
            WriteLine("--------------------------\nListe des Professeurs\n--------------------------\n"); 
            foreach (var Item in professeurs){
                WriteLine(Item);
            }
        }
           static Enrollment EnrollInEtudiant(Etudiant etudiant,Cours course){
            var cours=course;
            var enroll=etudiant.Enroller(course);
            if(enroll=="bad")
                WriteLine($"Allready enrolled in {course.Intitule}");
            else {
                //WriteLine("Cours ajouter: "+course.Intitule);
            }
             return new Enrollment(etudiant,course);
                
            }
            static void Enrollements(){
                 foreach(var Item in enrollments){
                     WriteLine(Item);
            }
    }
}
}
