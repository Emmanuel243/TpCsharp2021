namespace Ecole.Models{
    public class Cotation{
        public Cotation(Etudiant etudiant,Cours course,double coteExamen, double moyenne) 
        {
                this.Etudiant=etudiant;
                this.Course= course;
                this.CoteExamen = coteExamen;
                this.Moyenne = moyenne;
               
        }
        public Etudiant Etudiant{ get; private set;}
        public Cours Course{get; private set;}
        public double CoteExamen{get; private set;}
        public double Moyenne{get; private set;}
    }
}