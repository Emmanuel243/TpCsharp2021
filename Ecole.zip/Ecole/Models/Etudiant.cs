using System.Collections.Generic;
namespace Ecole.Models{
    public class Etudiant : Personne{
        public Etudiant(string nom, string postnom, string prenom, int age, char genre,string matricule, string emails, double pourcentage):base(nom,postnom,prenom,age,genre)
        {
            Matricule = matricule;
            Emails = emails;
            Pourcentage = pourcentage;
            Enrollments=new List<Enrollment>();
            Moyenne=new List<Cotation>();
        }
       
       public string Matricule{get;private set;} 
       public string Emails{get; private set;}
       public double Pourcentage{get; private set;}
       public List<Cotation> Moyenne{get; private set;}
       public List<Cours> Course { get; private set;}
       public List<Enrollment> Enrollments{ get; private set;}
         public string Enroller(Cours course){
           foreach(var Item in Enrollments){
                if(Item.course.Intitule==course.Intitule){
                    return ("bad");
                }
            }
            var enrollment=new Enrollment(this,course);
            Enrollments.Add(enrollment);
            return ("Ok");
          
        }
       public string Desenroller(string course){
           foreach(var Item in Enrollments){
            if(Item.course.Intitule==course){
                Enrollments.Remove(Item);
                return "Ok";
            }
       }
       return "Bad";
       }
       public override string ToString() => $"Matricule : {Matricule} Nom : {Nom} Postnom : {Postnom} Prenom: {Prenom} Age : {Age} Genre : {Genre}";
    }
}