namespace Ecole.Models{
        public class Enrollment{
        public Enrollment(Etudiant etudiant, Cours course)
        {
            this.etudiant = etudiant;
            this.course = course;
        }
           public Enrollment(Professeur profeusseur, Cours course)
        {
            this.professeur = professeur;
            this.course = course;
        }
        
        public Etudiant etudiant { get; private set; }
        public Cours course { get; set; }
        public Professeur professeur{get; private set;}
         public override string ToString() => $" Nom de la Personne : {etudiant.Nom} Cours : {course.Intitule} \n";
    }
}