using System.Collections.Generic;
namespace Ecole.Models{
   public class Professeur : Personne
{
   
        public Professeur(string nom, string postnom, string name, int age, char genre,string matricule, string emails) : base(nom,postnom,name,age,genre)
        {
                this.Matricule = matricule;
                this.Emails = emails;
                Enrollments=new List<Enrollment>();
               
        }
           public string Matricule{get; private set;}
            public string Emails{get; private set;}
       public List<Enrollment> Enrollments{ get; private set;}
         public string Enroller(Cours course){
           foreach(var Item in Enrollments){
                if(Item.course.Intitule==course.Intitule){
                    return ("bad");
                }
            }
            var enrollment=new Enrollment(this,course);
            Enrollments.Add(enrollment);
            return ("Ok");
          
        }
          public string Desenroller(string course){
           foreach(var Item in Enrollments){
            if(Item.course.Intitule==course){
                Enrollments.Remove(Item);
                return "Ok";
            }
       }
       return "Bad";
       }
       public override string ToString() => $"Matricule : {Matricule} Nom : {Nom} Postnom : {Postnom} Prenom: {Prenom} Age : {Age} Genre : {Genre}";
}
}

