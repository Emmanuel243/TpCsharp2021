using System.Collections.Generic;
namespace Ecole.Models{
    public class Cours{
        public Cours(string numero, string intitule, int volumehoraire) 
        {
                this.Numero = numero;
                this.Intitule = intitule;
                this.Volumehoraire = volumehoraire;
               
        }
        public string Numero{get; private set;}
        public string Intitule{get; private set;}
        public int Volumehoraire{get; private set;}
         public override string ToString() => $"Numero : {Numero} Intitule : {Intitule} VH: {Volumehoraire}";
    }
}