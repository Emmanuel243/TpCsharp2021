namespace Ecole.Models{
    public class Personne{
        public Personne(string nom, string postnom, string prenom, int age, char genre) 
        {
                this.Nom = nom;
                this.Postnom = postnom;
                this.Prenom = prenom;
                this.Age = age;
                this.Genre = genre;
               
        }
        public string Nom{ get; set; }
        public string Postnom{get; set; }
        public string Prenom{ get; set; }
        public int Age{ get; set; }
        public char Genre{ get; set;}
    }
}